    - Space X envisions a future where humans can live and thrive on multiple planets, ensuring the long-term survival of the human species.

