alias:: Founder's commitment
page-type:: [[key]]
innbok-key-rating:: 55
- #### is the entrepreneur comitted to the project? did s___he put his___her own money in the venture? is he dedicated on a full time basis?
- #questions
  - #question Is the entrepreneur fully committed to the startup?
  - #question Has the entrepreneur invested personal funds into the venture?
  - #question Is the entrepreneur dedicated full-time to the startup?
- #Risks

  - ### Founder's Commitment
  - Lack of commitment can hinder the progress and growth of the startup.
  - #### mitigation strategy
  - Evaluate the level of commitment of the founder to the startup and assess if they have invested personal funds and are dedicated full-time.
  - #### contingency strategy
  - Foster a culture of commitment and dedication within the startup.
- #TODOs
  - TODO Evaluate the commitment of the founder to the startup
  - TODO  Determine if they have invested personal funds and are dedicated full-time.


