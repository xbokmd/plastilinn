      - #asset [[Contracts and budget]]
       Space agencies have contracts and budgets allocated to carry out their space missions. Space X can seek to obtain contracts for satellite launches, cargo resupply missions, or even contracts to transport astronauts to space.
       #asset [[Access to launchers and launch platforms]]
       Space agencies have access to launch platforms, such as launch bases and space centers, which are vital for carrying out space missions. Space X could seek to use these facilities to launch their rockets and carry out their missions.
       #asset [[Experience and technical knowledge]]
       Space agencies have experts and scientists with experience in space missions and space technology. Space X can seek to collaborate with these experts and acquire specialized technical knowledge to improve their own capabilities and technologies.
       #asset [[Data and scientific_information]]
       During space missions, agencies collect a large amount of scientific and research data. Space X can seek to access this data and scientific_information for their own analysis and development of space technology.
       #asset [[International relations and collaborations]]
       Space agencies often have established relationships with other national and international space agencies. Space X can seek to collaborate with these agencies and leverage these relationships to access international markets and expand their global reach.

