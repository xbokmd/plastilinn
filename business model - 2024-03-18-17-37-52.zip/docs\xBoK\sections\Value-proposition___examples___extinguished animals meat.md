      - #segment_id [[Luxury food enthusiasts]]
       Individuals who have a passion for unique and exclusive gastronomic experiences.
       #profile_id [[Gourmet food connoisseurs]]
       Discerning individuals who appreciate and seek out high-quality, rare, and novel food products.
       #value_proposition [[Indulge in the rare and exquisite flavors of revived extinct animal meat]]
       Our company offers a once-in-a-lifetime opportunity to taste the flavors of ancient species brought back to life through biotechnology and genetic engineering.
       #action [[Purchase our exclusive luxury meat products]]
       Luxury food enthusiasts are encouraged to purchase our revived extinct animal meat products for an extraordinary dining experience.
       #reason [[Experience the ultimate in gastronomic luxury and novelty]]
       By consuming our revived extinct animal meat, customers can indulge in a truly unique and extraordinary gastronomic experience, unlike anything else available in the market.

