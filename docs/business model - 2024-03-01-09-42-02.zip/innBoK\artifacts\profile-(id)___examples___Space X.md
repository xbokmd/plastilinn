    - [[Space Agency Procurement Manager]]
     The procurement manager is responsible for managing the acquisition process, including identifying potential suppliers, issuing requests for proposals (RFPs), evaluating proposals, and negotiating contracts.

