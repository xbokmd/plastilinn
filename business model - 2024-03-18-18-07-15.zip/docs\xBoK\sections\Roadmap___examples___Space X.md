      #roadmap Phase 1
  Development and testing of reusable rocket technology.

#roadmap Phase 2
  Launching and deploying satellites for commercial and government customers.

#roadmap Phase 3
  Conducting resupply missions to the International Space Station.

#roadmap Phase 4
  Developing and launching crewed missions to the International Space Station.

#roadmap Phase 5
  Establishing a sustainable presence on Mars.

