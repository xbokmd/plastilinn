alias:: Capital structure
page-type:: [[key]]
innbok-key-rating:: 50
- #### what is the capital structure of the business? How is it funded and what is the financial leverage?
- #questions
  - #question What
- #Risks

  - ### Capital Structure
  - Inefficient capital structure can impact the financial health of the startup.
  - #### mitigation strategy
  - Evaluate the capital structure and funding sources of the business.
  - #### contingency strategy
  - Optimize the capital structure and leverage financial leverage effectively.
- #TODOs
  - TODO Evaluate the capital structure of the business
  - TODO  Determine how it is funded and what the financial leverage is.


