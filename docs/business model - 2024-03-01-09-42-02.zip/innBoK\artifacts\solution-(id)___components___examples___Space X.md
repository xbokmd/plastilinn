      - Rocket engines
       Propellant tanks
       Avionics systems
       Guidance and navigation systems
       Payload fairings
       Heat shields
       Solar panels
       Communication systems
       Life support systems (for crewed missions)
       Landing legs (for reusable rockets)
       Parachutes (for cargo recovery)
       Mars colonization infrastructure (habitat modules, life support systems, etc.)
       Satellite communication systems (for Starlink)
       Ground control systems
       Launch pads and facilities.

