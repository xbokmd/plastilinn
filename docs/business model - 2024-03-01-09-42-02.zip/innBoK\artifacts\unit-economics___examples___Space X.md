    - [[Rocket unit economics]]
     Analyzing the revenue and costs associated with manufacturing and launching a single rocket. This includes factors such as the selling price of the rocket, the cost of materials and manufacturing, the cost of launch operations, and any additional revenue or costs associated with the specific mission or payload.
     [[Satellite unit economics]]
     Analyzing the revenue and costs associated with manufacturing and deploying a single satellite. This includes factors such as the selling price of the satellite, the cost of materials and manufacturing, the cost of satellite deployment, and any additional revenue or costs associated with the specific satellite mission or customer.
     [[Service unit economics]]
     Analyzing the revenue and costs associated with providing a specific service, such as satellite communication services or launch services, to a single customer. This includes factors such as the subscription or service fees charged to the customer, the cost of providing the service, and any additional revenue or costs associated with the specific customer or service level.

