  - Revolutionize space technology and make space travel more accessible and affordable
   Develop reusable rockets and spacecraft to reduce the cost of space missions
   Establish a sustainable presence on Mars and enable human colonization

