alias:: Competency scope
page-type:: [[key]]
innbok-key-rating:: 40
- #### are the skills necessary to successfully build the company present in the team members?
- #questions
  - #question Do team members possess the necessary skills and expertise?
  - #question Are there any skill gaps within the team?
  - #question Is the team capable of executing the business plan effectively?
- #Risks

  - ### Competency Scope
  - Lack of necessary skills and expertise within the team can hinder the execution of the business plan.
  - #### mitigation strategy
  - Assess the competency scope of the team and determine if they possess the necessary skills and expertise.
  - #### contingency strategy
  - Identify skill gaps within the team and consider hiring or training to fill those gaps.
- #TODOs
  - TODO Assess the competency scope of the team
  - TODO  Determine if they possess the necessary skills and expertise.


