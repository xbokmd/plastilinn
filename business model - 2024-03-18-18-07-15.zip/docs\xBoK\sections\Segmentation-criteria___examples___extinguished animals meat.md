      - #segmentation [[Firmographic segmentation]]
       Categorizing B2B markets based on industry type, company size, location, and purchasing power.
       #segmentation [[Geographic segmentation]]
       Dividing the market based on location, climate, population density, and cultural differences.
       #segmentation [[Demographic segmentation]]
       Categorizing the market based on age, gender, income, occupation, and education.
       #segmentation [[Psychographic segmentation]]
       Segmenting the market based on psychological characteristics, attitudes, beliefs, values, interests, and lifestyles.
       #segmentation [[Behavioral segmentation]]
       Classifying the market based on consumer behavior, including purchase patterns, usage rate, loyalty, and benefits sought.

