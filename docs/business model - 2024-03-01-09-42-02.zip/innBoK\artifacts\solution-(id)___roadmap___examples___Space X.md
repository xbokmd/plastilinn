      - #phase [[Phase 1]]
       Development and testing of reusable rocket technology.
       #phase [[Phase 2]]
       Launching and deploying satellites for commercial and government customers.
       #phase [[Phase 3]]
       Conducting resupply missions to the International Space Station.
       #phase [[Phase 4]]
       Developing and launching crewed missions to the International Space Station.
       #phase [[Phase 5]]
       Establishing a sustainable presence on Mars.

