- phase
  - #[[phase]]  [[Idea Stage]]
  - #[[phase]]  [[Seed Stage]]
  - #[[phase]]  [[Growth Stage]]

