    #work Rocket design and manufacturing
Space X must design and manufacture rockets that are safe, reliable, and cost-effective for space transportation.

#work Launch and mission management
Space X must provide launch and mission management services to ensure successful placement of payloads in space.

#work Satellite design and manufacturing
Space X must design and manufacture satellites capable of providing communication services to clients in space.

#work Satellite deployment and management
Space X must provide satellite deployment and management services to ensure successful operation of satellites in space.

#work Research and development
Space X must invest in research and development to improve its rockets and satellites and stay ahead of the competition.

