color:: blue
icon:: 🔧
page-type:: [[class]]
alias:: skills

- ### Definition 
  - "skill" refers to the specific abilities, knowledge, or expertise required to perform certain tasks or functions within the business model. Skills can be technical, such as programming or design skills, or soft skills, such as communication or leadership skills. Having the right skills within the team is essential for achieving business goals and delivering value to customers. Businesses may need to invest in training or hiring to ensure that they have the necessary skills to succeed.
- ### Sample list
  - [How to copy this list]([[plastilinn/Copy block]])
  - #inn-edit {{embed [[skill/list]]}}


