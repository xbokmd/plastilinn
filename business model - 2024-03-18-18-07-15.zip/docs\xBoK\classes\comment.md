color:: 
icon:: 🗨️
page-type:: [[class]]
alias:: comments

- ### Definition 
  - A comment is a statement or feedback provided by an individual or group regarding a specific aspect of the business. Comments can be positive or negative and can provide valuable insights into customer preferences, satisfaction levels, and areas for improvement. Businesses can use comments to identify trends, address concerns, and improve their overall customer experience. Comments can be gathered through various channels such as surveys, social media, or customer support interactions.
- ### Sample list
  - [How to copy this list]([[plastilinn/Copy block]])
  - #inn-edit {{embed [[comment/list]]}}


