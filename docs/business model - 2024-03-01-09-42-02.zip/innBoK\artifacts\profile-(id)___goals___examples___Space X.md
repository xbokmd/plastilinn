      - #goal [[Falcon 9]]
       A two-stage rocket designed for reliable and cost-effective transportation of satellites and spacecraft to orbit. It is capable of carrying payloads of up to 22,800 kilograms to low Earth orbit and 8,300 kilograms to geostationary transfer orbit.
       #goal [[Falcon Heavy]]
       A heavy-lift launch vehicle that is currently the most powerful operational rocket in the world. It is capable of carrying payloads of up to 63,800 kilograms to low Earth orbit and 26,700 kilograms to geostationary transfer orbit.
       #goal [[Starlink]]
       A constellation of satellites being built by Space X to provide global broadband internet coverage. Its goal is to provide high-speed, low-latency internet access to users worldwide, especially in underserved areas.
       #goal [[Dragon spacecraft]]
       A reusable spacecraft designed for cargo and crewed missions. It is capable of carrying up to 7 passengers to and from the International Space Station and can also deliver cargo to other destinations in space.
       #goal [[Mars colonization]]
       Space X's long-term goal is to enable the colonization of Mars. They are developing the Starship spacecraft, which is intended to transport humans and cargo to Mars to establish a sustainable presence on the planet.
       #goal [[Starship]]
       A fully reusable spacecraft currently under development by Space X. It is designed to be capable of transporting both crew and cargo to various destinations in space, including the Moon, Mars, and beyond.

