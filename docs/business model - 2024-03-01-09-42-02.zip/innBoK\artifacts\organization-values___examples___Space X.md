    - [[innovation]]
     The development and implementation of new ideas, products, or processes that bring about positive change and improvement.
     [[sustainability]]
     The practice of using resources in a way that meets the needs of the present generation without compromising the ability of future generations to meet their own needs.
     [[the pursuit of knowledge]]
     The act of seeking and acquiring_information, understanding, or skills through study, research, or exploration.

