<!--
Go to https://xbokmd.github.io/plastilinn/app.html and load this document
More info plastilinn.com
-->

# Business idea

## Opportunity

## Inspiration

## Business status

## Challenges

## Unfair advantage

# Business objectives

## Mission

## Vision

## Strategy

## Organization values

## Organization goals

# Stakeholders

# Segment list

## #segment Main segment

### #segment Main segment - Segmentation criteria

### #segment Main segment - Market size

### #segment Main segment - Market trends

### #segment Main segment - Partners

### #segment Main segment - Competition

### #segment Main segment - Roles

# Profile list

## #profile Main profile

### #profile Main profile - Segmentation

### #profile Main profile - Persona

### #profile Main profile - Goals

### #profile Main profile - Perceptions

### #profile Main profile - Emotions

### #profile Main profile - Value proposition

#### #profile Main profile - Quantified value proposition

### #profile Main profile - Relationship

### #profile Main profile - Messages

### #profile Main profile - Channels

### #profile Main profile - Assets

### #profile Main profile - Transactions

### #profile Main profile - Journey

### #profile Main profile - Funnel

### #profile Main profile - Sales strategy

# Solution list

## #solution Main solution

### #solution Main solution - Category

### #solution Main solution - Components

### #solution Main solution - Features

### #solution Main solution - Roadmap

### #solution Main solution - Offerings

### #solution Main solution - Profiles

### #solution Main solution - Pricing

### #solution Main solution - Brochure

# Marketing

## Naming

## Branding

## Visual identity

## Logo

## Marketing plan

# Operations

## Activitiy list

## Function list

## Resource list

# Metric list

## Life time value

## Customer aquisition cost

# Team

## People

### #person Main person

#### #person Main person - Goals

#### #person Main person - Skills

#### #person Main person - Functions

#### #person Main person - Contributions

#### #person Main person - Compensations

## Position list

# Project plan

## Phases

## Milestones

# Finance

## Revenue lines

## Cost lines

## Unit economics

## Funding strategy

## Funding sources

## Capital structure

### Cap table

## Cashflow projections

## Finantial projections

# Legal

## Legal issues

## Contract list

# Communication

## Pitch

## Business brochure

## Web

## Storytelling

## Presentations

# Analysis

## Assumption list

## Risk list

# Validation

## Experiment list

### #experiment Main experiment

# References

# Artifacts

# Keys

# Attachments

