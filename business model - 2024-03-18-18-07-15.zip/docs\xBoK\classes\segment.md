color:: blue
icon:: 🙋
page-type:: [[class]]
alias:: segmentations

- ### Definition 
  - 
- ### Sample list
  - [How to copy this list]([[plastilinn/Copy block]])
  - #inn-edit {{embed [[segment/list]]}}


