  #stakeholder Satellite Launch Customers
This segment consists of commercial and government organizations that require satellite launch services. They are looking for a reliable and cost-effective platform to deploy their satellites and enhance their communication and Earth observation capabilities.

#stakeholder Space Exploration Enthusiasts
 This segment comprises individuals who are passionate about space exploration and are interested in participating in missions beyond low Earth orbit. They are looking for opportunities to travel to the Moon, Mars, and other destinations in the solar system.

#stakeholder Space Tourism Customers
This segment consists of individuals and groups who are interested in experiencing weightlessness and enjoying unique views of Earth from space. They are willing to pay for the opportunity to become space tourists and have a once-in-a-lifetime experience.

#stakeholder Advanced Space Technology Developers
This segment includes researchers and developers who are focused on advancing space technology. They are looking for partnerships and collaborations to improve efficiency and safety in space missions, particularly in propulsion systems, lightweight materials, and precise landing technologies.


