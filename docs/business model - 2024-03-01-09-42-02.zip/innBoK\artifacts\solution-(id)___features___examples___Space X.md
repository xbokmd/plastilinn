      - #feature [[Reusable first stage]]
       A component of Space X's rockets that is designed to be reused multiple times, reducing the cost of space launches. It is the first stage of the rocket that provides the initial thrust to lift the rocket off the ground.
       #feature [[Payload capacity]]
       The maximum weight or mass that a rocket can carry into space. It is an important factor in determining the types and sizes of satellites or spacecraft that can be launched.
       #feature [[Advanced avionics]]
       The electronic systems and components used in spacecraft and rockets for navigation, control, and communication. Advanced avionics technology allows for more precise and efficient operations in space missions.

