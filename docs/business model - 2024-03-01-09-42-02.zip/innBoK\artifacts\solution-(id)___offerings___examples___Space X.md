      - #offering [[Servicios de lanzamiento espacial]]
       Servicios de lanzamiento al espacio para satélites y naves espaciales.
       #offering [[Despliegue de satélites]]
       Despliegue de satélites en órbita.
       #offering [[Misiones de abastecimiento a la Estación Espacial Internacional]]
       Misiones de abastecimiento de suministros a la Estación Espacial Internacional.
       #offering [[Misiones tripuladas a la Estación Espacial Internacional]]
       Misiones con tripulación humana a la Estación Espacial Internacional.
       #offering [[Tecnologías avanzadas de cohetes y naves espaciales]]
       Desarrollo de tecnologías avanzadas en cohetes y naves espaciales.
       #offering [[Colonización futura de Marte]]
       Objetivo a largo plazo de Space X de habilitar la colonización de Marte.

