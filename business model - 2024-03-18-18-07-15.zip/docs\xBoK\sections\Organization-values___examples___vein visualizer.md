    -  [[integrity]]
     Upholding honesty, transparency, and ethical behavior in all business dealings.
      [[collaboration]]
     Encouraging teamwork, cooperation, and open communication to achieve shared goals.
      [[customer-centricity]]
     Prioritizing the needs and satisfaction of customers, providing exceptional service and value.
      [[continuous improvement]]
     Striving for ongoing learning, growth, and innovation to constantly enhance products and processes.
      [[social responsibility]]
     Taking into account the impact of business decisions on society and actively contributing to the well-being of communities and the environment.

