alias:: Founder's capacity
page-type:: [[key]]
innbok-key-rating:: 65
- #### does the entrepreneur have enough knowledge, skills and experience? does he speak languages?
- #questions
  - #question Does the entrepreneur have the necessary knowledge, skills, and experience?
  - #question Does the entrepreneur speak multiple languages?
  - #question Is the entrepreneur capable of leading the startup?
- #Risks

  - ### Founder's Capacity
  - Lack of knowledge, skills, and experience can impact the success of the startup.
  - #### mitigation strategy
  - Assess the knowledge, skills, and experience of the founder and determine if they are sufficient to lead the startup.
  - #### contingency strategy
  - Provide training and development opportunities to enhance the founder's capacity.
- #TODOs
  - TODO Assess the knowledge, skills, and experience of the founder
  - TODO  Determine if they possess the


