    - The company envisions a future where humanity can experience the unique tastes and flavors of extinct animals, while promoting ethical and sustainable practices in biotechnology and genetic engineering.
     They strive to redefine the luxury food market by offering exclusive and exceptional gastronomic experiences, while contributing to the conservation of biodiversity and respecting animal life.

