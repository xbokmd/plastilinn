    - #function [[Scientific research and technological development]]
     The company must invest in R&D to understand and manipulate the DNA of extinct animals.
     #function [[Cloning and assisted reproduction techniques]]
     The company must use cloning and reproduction methods to create living individuals of extinct species.
     #function [[Facilities and care centers management]]
     The company must establish and manage facilities for housing and breeding revived extinct animals.
     #function [[Meat production and processing]]
     The company must ethically slaughter and process the meat of revived extinct animals.
     #function [[Marketing and sales strategies]]
     The company must implement marketing strategies to promote and sell its luxury meat products.

