    - Space X's mission is to make life multiplanetary by developing the technologies necessary for space exploration and colonization

