alias:: Vertical experience
page-type:: [[key]]
innbok-key-rating:: 15
- #### do founders have industry-specific knowledge and expertise?
- #questions
  - #question Does the entrepreneur have industry-specific knowledge and expertise?
  - #question Is the entrepreneur familiar with the market and industry?
  - #question Does the entrepreneur have relevant experience in the field?
- #Risks

  - ### Vertical Experience
  - Lack of industry-specific knowledge and expertise can hinder the ability to effectively navigate the market.
  - #### mitigation strategy
  - Assess the industry-specific knowledge and expertise of the founder and determine if they have relevant experience in the field.
  - #### contingency strategy
  - Consider if the entrepreneur has industry-specific knowledge and expertise and if they are familiar with the market and industry.
- #TODOs
  - TODO Assess the industry-specific knowledge and expertise of the founder
  - TODO  Determine if they have relevant experience in the field.


