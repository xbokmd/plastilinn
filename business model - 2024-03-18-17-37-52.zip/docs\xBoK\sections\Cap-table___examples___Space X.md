      Cap table (fictional)

| Shareholder Type            | Name/Group            | Shares Owned | Ownership % |
|-----------------------------|-----------------------|--------------|-------------|
| Founders                    | Elon Musk             | 150,000,000  | 54%         |
| Venture Capital             | Google & Fidelity     | 30,000,000   | 11%         |
| Venture Capital             | Founders Fund         | 20,000,000   | 7%          |
| Venture Capital             | Sequoia Capital       | 10,000,000   | 3.6%        |
| Other Investors             | Various (Angel & VC)  | 25,000,000   | 9%          |
| Government Contracts (Note) | Reserved for future   | 0            | 0%          |
| Employee Stock Options Pool | Reserved for employees| 40,000,000   | 14.4%       |
| **Total**                   |                       | **275,000,000** | **100%** |


