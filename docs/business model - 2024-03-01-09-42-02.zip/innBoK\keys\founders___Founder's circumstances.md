alias:: Founder's circumstances
page-type:: [[key]]
innbok-key-rating:: 20
- #### what is his___her personal situation? is s___he married? is s___he young? does s___he have kids?
- #questions
  - #question What is the personal situation of the entrepreneur?
  - #question Does the entrepreneur have any personal constraints or obligations?
  - #question Is the entrepreneur in a favorable position to focus on the startup?
- #Risks

  - ### Founder's Circumstances
  - Personal constraints or obligations can impact the founder's ability to focus on the startup.
  - #### mitigation strategy
  - Evaluate the personal situation of the founder and determine if they are in a favorable position to focus on the startup.
  - #### contingency strategy
  - Provide support and flexibility to accommodate the founder's personal circumstances.
- #TODOs
  - TODO Evaluate the personal situation of the founder
  - TODO  Determine if they are in a favorable position to focus on the startup.


