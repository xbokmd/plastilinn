    Elon Musk
He is the primary shareholder and owner of SpaceX, holding 42% equity and having 79% voting control.

Private Investors
Over the years, SpaceX has raised capital through various funding rounds, with investors contributing to the company's valuation. Notable investors include Google and Fidelity, who, in January 2015, invested $1 billion in exchange for 8.33% of the company.

Employees
It's common for tech companies, including SpaceX, to offer stock options to employees. However, specific details about individual employee ownership or other minor shareholders were not provided in the content.

