    - #segment [[Government Agencies]]
     The government agencies segment includes national space agencies that require space transportation and communication services for their missions.

